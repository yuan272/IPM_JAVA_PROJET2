import java.sql.SQLException;
import java.util.Scanner;

import Ecole.Jeu.*;
import Ecole.Personnages.Eleve;
import dao.*;
import ExceptionClasses.*;
import utils.Functions;

public class Main2 {
    private static EleveDAO eleveDAO = new EleveDAO();
    private static MaisonDAO maisonDAO = new MaisonDAO();
    private static MatiereDAO matiereDAO = new MatiereDAO();
    private static EvaluerDAO evaluerDAO = new EvaluerDAO();
    private static PartieDAO partieDAO = new PartieDAO();
    private static PropositionPartieDAO propositionPartieDAO = new PropositionPartieDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Functions.printWithDelay("== 🧙🏻✨ Bienvenue à Poudlard ✨🧙🏻 ==\n", 60);

        while (true) {
            afficherMenu();
            int choix = lireChoixUtilisateur();
            traiterChoix(choix);
        }
    }

    private static void afficherMenu() {
        Functions.printWithDelay("\nQue souhaitez-vous faire ? 🪄\n", 60);
        Functions.printWithDelay("1. Afficher les élèves et leur maison\n", 2);
        Functions.printWithDelay("2. Créer un élève et l'affecter à une maison\n", 2);
        Functions.printWithDelay("3. Évaluer un élève\n", 2);
        Functions.printWithDelay("4. Afficher le classement par maison\n", 2);
        Functions.printWithDelay("5. Afficher le top 10 des élèves\n", 2);
        Functions.printWithDelay("6. Jouer une partie de Chifoumi\n", 2);
        Functions.printWithDelay("7. Quitter\n", 2);
    }

    private static int lireChoixUtilisateur() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            Functions.printWithDelay("Entrée non reconnue, veuillez entrer un nombre valide.\n", 10);
            return -1;
        }
    }

    private static void traiterChoix(int choix) {
        try {
            switch (choix) {
                case 1:
                    Functions.afficherElevesEtMaison(eleveDAO, scanner);
                    break;
                case 2:
                    Functions.creerEleveEtAffecterMaison(eleveDAO, maisonDAO, scanner);
                    break;
                case 3:
                    Functions.evaluerEleve(eleveDAO, matiereDAO, evaluerDAO, scanner);
                    break;
                case 4:
                    Functions.afficherClassementMaisons(eleveDAO);
                    break;
                case 5:
                    Functions.afficherTop10Eleves(eleveDAO);
                    break;
                case 6:
                    jouerPartieChifoumi();
                    break;
                case 7:
                    Functions.printWithDelay("🧙🏻 Au revoir !\n", 10);
                    scanner.close();
                    System.exit(0);
                default:
                    Functions.printWithDelay("Choix non reconnu, veuillez réessayer.\n", 10);
            }
        } catch (Exception e) {
            Functions.printWithDelay("Une erreur est survenue : " + e.getMessage() + "\n", 10);
            e.printStackTrace();
        }
    }

    private static void jouerPartieChifoumi() throws SQLException, DatabaseException, AucunEleveTrouveException, EleveNonTrouveException {
        Functions.printWithDelay("\nJouer une partie de Chifoumi\n", 10);
        
        // Vérifier si le jeu Chifoumi existe, sinon l'ajouter
        JeuDAO jeuDAO = new JeuDAO();
        Jeu jeuChifoumi = verifierOuCreerJeuChifoumi(jeuDAO);
        if (jeuChifoumi == null) {
            return; // Sortir de la méthode si on ne peut pas obtenir ou créer le jeu
        }

        // Sélection des joueurs
        Eleve joueur1 = selectionnerJoueurChifoumi(eleveDAO, scanner, "Sélectionnez le premier joueur");
        if (joueur1 == null) return;

        Eleve joueur2 = selectionnerJoueurChifoumi(eleveDAO, scanner, "Sélectionnez le deuxième joueur");
        if (joueur2 == null) return;

        // Détermination de la mise
        int miseMax = Math.min(joueur1.getTotalPoints(), joueur2.getTotalPoints());
        int mise = demanderMise(miseMax);

        // Jouer la partie
        Chifoumi partie = new Chifoumi(joueur1, joueur2, mise);
        partie.jouer();

        // Traiter le résultat
        traiterResultatPartie(partie, jeuChifoumi, joueur1, joueur2, mise);
    }

    private static Jeu verifierOuCreerJeuChifoumi(JeuDAO jeuDAO) throws SQLException, DatabaseException {
        try {
            return jeuDAO.getJeuByNom("Chifoumi");
        } catch (JeuNonTrouveException e) {
            Jeu jeuChifoumi = new Jeu("Chifoumi");
            try {
                jeuDAO.ajouterJeu(jeuChifoumi);
                Functions.printWithDelay("Le jeu Chifoumi a été ajouté avec succès.\n", 10);
                return jeuChifoumi;
            } catch (SQLException | DatabaseException ex) {
                Functions.printWithDelay("Erreur lors de l'ajout du jeu Chifoumi : " + ex.getMessage() + "\n", 10);
                return null;
            }
        }
    }

    private static int demanderMise(int miseMax) {
        int mise;
        do {
            System.out.println("Entrez la mise (entre 1 et " + miseMax + ") :");
            mise = scanner.nextInt();
            scanner.nextLine(); // Consommer la nouvelle ligne
            if (mise < 1 || mise > miseMax) {
                Functions.printWithDelay("Mise invalide. Veuillez entrer un nombre entre 1 et " + miseMax + ".\n", 10);
            }
        } while (mise < 1 || mise > miseMax);
        return mise;
    }

    private static void traiterResultatPartie(Chifoumi partie, Jeu jeuChifoumi, Eleve joueur1, Eleve joueur2, int mise) throws SQLException, DatabaseException {
        Eleve vainqueur = partie.getVainqueur();

        PropositionPartie proposition = new PropositionPartie(0, mise, false, vainqueur, joueur1, joueur2, jeuChifoumi);
        int idProposition = propositionPartieDAO.proposerPartie(proposition);
        proposition.setIdProposition(idProposition);

        if (vainqueur != null) {
            partieDAO.enregistrerPartie(proposition, vainqueur.getIdEleve());
            eleveDAO.mettreAJourPoints(vainqueur.getIdEleve(), mise);
            eleveDAO.mettreAJourPoints(vainqueur == joueur1 ? joueur2.getIdEleve() : joueur1.getIdEleve(), -mise);
            Functions.printWithDelay("Le vainqueur est " + vainqueur.getPrenom() + " " + vainqueur.getNom() + " !\n", 10);
        } else {
            partieDAO.enregistrerPartie(proposition, null);
            Functions.printWithDelay("Match nul ! Les points restent inchangés.\n", 10);
        }
    }
    private static Eleve selectionnerJoueurChifoumi(EleveDAO eleveDAO, Scanner scanner, String message) throws SQLException, DatabaseException, AucunEleveTrouveException, EleveNonTrouveException {
        Eleve joueurSelectionne = null;
        while (joueurSelectionne == null) {
            Eleve eleve = Functions.selectionnerEleve(eleveDAO, scanner, message);
            if (eleve.getTotalPoints() < 1) {
                Functions.printWithDelay("Cet élève n'a pas assez de points pour jouer (minimum 1 point requis).\n", 10);
            } else {
                joueurSelectionne = eleve;
            }
        }
        return joueurSelectionne;
    }
}