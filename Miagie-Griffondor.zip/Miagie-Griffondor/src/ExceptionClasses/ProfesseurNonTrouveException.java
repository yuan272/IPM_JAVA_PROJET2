package ExceptionClasses;

public class ProfesseurNonTrouveException extends Exception {
    public ProfesseurNonTrouveException(String message) {
        super(message);
    }
}
