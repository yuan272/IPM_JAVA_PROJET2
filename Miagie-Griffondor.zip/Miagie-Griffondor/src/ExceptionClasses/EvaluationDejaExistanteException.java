package ExceptionClasses;

public class EvaluationDejaExistanteException extends Exception {
    public EvaluationDejaExistanteException(String message) {
        super(message);
    }
}