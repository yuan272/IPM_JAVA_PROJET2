package ExceptionClasses;

public class MatiereNonTrouveeException extends Exception {
    public MatiereNonTrouveeException(String message) {
        super(message);
    }
}
