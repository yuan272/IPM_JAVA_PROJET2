package ExceptionClasses;

public class AucuneMatiereTrouveeException extends Exception {
    public AucuneMatiereTrouveeException(String message) {
        super(message);
    }
}
