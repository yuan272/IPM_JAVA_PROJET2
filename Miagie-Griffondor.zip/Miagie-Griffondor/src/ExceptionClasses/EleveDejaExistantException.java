package ExceptionClasses;

public class EleveDejaExistantException extends Exception{
	public EleveDejaExistantException(String message) {
		super(message);
	}

}
