package ExceptionClasses;

public class EvaluationNonTrouveeException extends Exception {
    public EvaluationNonTrouveeException(String message) {
        super(message);
    }
}
