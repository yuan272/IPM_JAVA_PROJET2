package ExceptionClasses;

public class MaisonDejaExistanteException extends Exception {
    public MaisonDejaExistanteException(String message) {
        super(message);
    }
}
