package ExceptionClasses;

public class AucunePartieTrouveeException extends Exception{
	public AucunePartieTrouveeException(String message) {
		super(message);
	}
}
