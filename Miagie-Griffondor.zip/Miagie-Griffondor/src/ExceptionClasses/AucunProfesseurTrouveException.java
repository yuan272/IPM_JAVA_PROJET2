package ExceptionClasses;

public class AucunProfesseurTrouveException extends Exception {
    public AucunProfesseurTrouveException(String message) {
        super(message);
    }
}
