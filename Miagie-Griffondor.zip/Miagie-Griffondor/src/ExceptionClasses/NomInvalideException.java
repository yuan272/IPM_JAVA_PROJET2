package ExceptionClasses;

public class NomInvalideException extends Exception {
    public NomInvalideException(String message) {
        super(message);
    }
}