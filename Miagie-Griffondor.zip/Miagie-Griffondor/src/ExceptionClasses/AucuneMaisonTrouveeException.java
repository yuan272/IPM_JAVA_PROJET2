package ExceptionClasses;

public class AucuneMaisonTrouveeException extends Exception {
    public AucuneMaisonTrouveeException(String message) {
        super(message);
    }
}
