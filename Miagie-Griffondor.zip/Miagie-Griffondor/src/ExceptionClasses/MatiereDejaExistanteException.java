package ExceptionClasses;

public class MatiereDejaExistanteException extends Exception {
    public MatiereDejaExistanteException(String message) {
        super(message);
    }
}
