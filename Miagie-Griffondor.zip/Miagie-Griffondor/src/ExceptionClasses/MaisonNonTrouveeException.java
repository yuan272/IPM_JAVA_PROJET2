package ExceptionClasses;

public class MaisonNonTrouveeException extends Exception {
    public MaisonNonTrouveeException(String message) {
        super(message);
    }
}
