package ExceptionClasses;

public class AucunEleveTrouveException  extends Exception{
	public AucunEleveTrouveException(String message) {
		super(message);
	}

}
