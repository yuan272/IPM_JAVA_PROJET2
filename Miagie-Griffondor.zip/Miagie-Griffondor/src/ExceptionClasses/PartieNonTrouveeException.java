package ExceptionClasses;

public class PartieNonTrouveeException extends Exception{
	public PartieNonTrouveeException(String message) {
		super(message);
	}

}
