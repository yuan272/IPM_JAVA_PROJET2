package ExceptionClasses;

public class AucuneEvaluationTrouveeException extends Exception {
    public AucuneEvaluationTrouveeException(String message) {
        super(message);
    }
}
