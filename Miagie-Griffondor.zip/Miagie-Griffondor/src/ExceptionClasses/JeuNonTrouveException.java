package ExceptionClasses;

public class JeuNonTrouveException extends Exception {
	public JeuNonTrouveException(String message) {
		super(message);
	}
}
