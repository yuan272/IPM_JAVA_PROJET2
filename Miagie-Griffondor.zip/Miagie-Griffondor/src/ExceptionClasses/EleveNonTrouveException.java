package ExceptionClasses;

public class EleveNonTrouveException extends Exception {
    public EleveNonTrouveException(String message) {
        super(message);
    }
}
