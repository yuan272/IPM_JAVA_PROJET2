package Ecole.Jeu;
import Ecole.Personnages.Eleve;

public class PropositionPartie {
    private int idProposition;
    private int mise;
    private boolean refuse;
    private Eleve eleveVainqueur;
    private Eleve eleveReceveur;
    private Eleve eleveLanceur;
    private Jeu jeu;

    public PropositionPartie(int idProposition, int mise, boolean refuse, Eleve eleveVainqueur, Eleve eleveReceveur, Eleve eleveLanceur, Jeu jeu) {
        this.idProposition = idProposition;
        this.mise = mise;
        this.refuse = refuse;
        this.eleveVainqueur = eleveVainqueur;
        this.eleveReceveur = eleveReceveur;
        this.eleveLanceur = eleveLanceur;
        this.jeu = jeu;
    }

    public int getIdProposition() {
        return idProposition;
    }
    
    

    public Jeu getJeu() {
		return jeu;
	}

	public void setIdProposition(int idProposition) {
        this.idProposition = idProposition;
    }

    public int getMise() {
        return mise;
    }

    public void setMise(int mise) {
        this.mise = mise;
    }

    public boolean isRefuse() {
        return refuse;
    }

    public void setRefuse(boolean refuse) {
        this.refuse = refuse;
    }

    public Eleve getEleveVainqueur() {
        return eleveVainqueur;
    }

    public void setEleveVainqueur(Eleve eleveVainqueur) {
        this.eleveVainqueur = eleveVainqueur;
    }

    public Eleve getEleveReceveur() {
        return eleveReceveur;
    }

    public void setEleveReceveur(Eleve eleveReceveur) {
        this.eleveReceveur = eleveReceveur;
    }

    public Eleve getEleveLanceur() {
        return eleveLanceur;
    }

    public void setEleveLanceur(Eleve eleveLanceur) {
        this.eleveLanceur = eleveLanceur;
    }

    @Override
    public String toString() {
        return "PropositionPartie{" +
                "idProposition=" + idProposition +
                ", jeu=" +jeu+
                ", mise=" + mise +
                ", refuse=" + refuse +
                ", eleveVainqueur=" + eleveVainqueur.getNom() +
                ", eleveReceveur=" + eleveReceveur.getNom() +
                ", eleveLanceur=" + eleveLanceur.getNom() +
                '}';
    }
}
