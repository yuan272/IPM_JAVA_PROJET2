package Ecole.Jeu;

import Ecole.Personnages.Eleve;

public class Jeu {
    protected String nomjeu;
    protected Eleve joueur1;
    protected Eleve joueur2;
    protected int mise;
    
 // Constructeur par d�faut
    public Jeu() {}

    // Constructeur avec seulement le nom
    public Jeu(String nomjeu) {
        this.nomjeu = nomjeu;
    }

    
    // Constructeur pour les jeux sp�cifiques
    public Jeu(String nomjeu, Eleve joueur1, Eleve joueur2, int mise) {
        this.nomjeu = nomjeu;
        this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.mise = mise;
    }
    
    // M�thodes qui peuvent �tre surcharg�es dans les classes filles
    public void jouer() {
        // Impl�mentation par d�faut ou vide
    }
    
    public Eleve getVainqueur() {
        // Impl�mentation par d�faut
        return null;
    }
    
    public void annoncerVainqueur() {
        // Impl�mentation par d�faut ou vide
    }

    public String getNomGame() {
        return nomjeu;
    }

    public void setNomGame(String nomGame) {
        this.nomjeu = nomGame;
    }

}