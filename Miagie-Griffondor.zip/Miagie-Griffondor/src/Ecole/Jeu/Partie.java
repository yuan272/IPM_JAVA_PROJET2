package Ecole.Jeu;

public class Partie {
    private int idPartie;
    private int idProposition;

    public Partie(int idPartie, int idProposition) {
        this.idPartie = idPartie;
        this.idProposition = idProposition;
    }

	    // Getters et setters

	    public int getIdPartie() {
	        return idPartie;
	    }

	    public void setIdPartie(int idPartie) {
	        this.idPartie = idPartie;
	    }

	
	    @Override
	    public String toString() {
	        return "Partie{" +
	                "idPartie=" + idPartie;
	    }
	}