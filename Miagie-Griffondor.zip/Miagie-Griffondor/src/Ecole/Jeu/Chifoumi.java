package Ecole.Jeu;

import java.util.Scanner;
import Ecole.Personnages.Eleve;
import utils.Functions;

public class Chifoumi extends Jeu {
    private static final String[] CHOIX = {"chaudron", "balai", "baguette"};
    private int scoreJoueur1 = 0;
    private int scoreJoueur2 = 0;
    private Eleve vainqueur = null;
    
    
    public Chifoumi(Eleve joueur1, Eleve joueur2, int mise) {
        super("Chifoumi", joueur1, joueur2, mise);
    }

    @Override
    public void jouer() {
        Scanner scanner = new Scanner(System.in);
        
        for (int manche = 1; manche <= 3; manche++) {
            Functions.printWithDelay("Manche " + manche + "\n", 10);
            
            String choixJoueur1 = demanderChoix(joueur1, scanner);
            String choixJoueur2 = demanderChoix(joueur2, scanner);
            
            int resultat = determinerVainqueurManche(choixJoueur1, choixJoueur2);
            
            if (resultat > 0) {
                Functions.printWithDelay(joueur1.getPrenom() + " gagne la manche!\n", 10);
                scoreJoueur1++;
            } else if (resultat < 0) {
                Functions.printWithDelay(joueur2.getPrenom() + " gagne la manche!\n", 10);
                scoreJoueur2++;
            } else {
                Functions.printWithDelay("égalité pour cette manche!\n", 10);
            }
            
            Functions.printWithDelay("Score actuel: " + joueur1.getPrenom() + " " + scoreJoueur1 + " - " + scoreJoueur2 + " " + joueur2.getPrenom() + "\n", 10);
        }
        
        determinerVainqueurPartie();
    }

    private String demanderChoix(Eleve joueur, Scanner scanner) {
        String choix;
        do {
            Functions.printWithDelay(joueur.getPrenom() + ", choisissez chaudron, balai ou baguette : ", 10);
            choix = scanner.nextLine().toLowerCase();
        } while (!choixValide(choix));
        return choix;
    }

    private boolean choixValide(String choix) {
        for (String c : CHOIX) {
            if (c.equals(choix)) {
                return true;
            }
        }
        return false;
    }

    private int determinerVainqueurManche(String choix1, String choix2) {
        if (choix1.equals(choix2)) {
            return 0;
        }
        if ((choix1.equals("baguette") && choix2.equals("balai")) ||
            (choix1.equals("balai") && choix2.equals("chaudron")) ||
            (choix1.equals("chaudron") && choix2.equals("baguette"))) {
            return 1;
        }
        return -1;
    }

    private void determinerVainqueurPartie() {
        if (scoreJoueur1 > scoreJoueur2) {
            vainqueur = joueur1;
            Functions.printWithDelay(joueur1.getPrenom() + " remporte la partie!\n", 10);
        } else if (scoreJoueur2 > scoreJoueur1) {
            vainqueur = joueur2;
            Functions.printWithDelay(joueur2.getPrenom() + " remporte la partie!\n", 10);
        } else {
            Functions.printWithDelay("La partie se termine sur une égalité!\n", 10);
        }
    }

    @Override
    public Eleve getVainqueur() {
        return vainqueur;
    }

    @Override
    public void annoncerVainqueur() {
        if (vainqueur != null) {
            int gainTotal = mise;
            Functions.printWithDelay("Le vainqueur est " + vainqueur.getPrenom() + " " + vainqueur.getNom() + "!\n", 10);
            Functions.printWithDelay("Il remporte " + gainTotal + " points!\n", 10);
        } else {
            Functions.printWithDelay("La partie s'est termin�e sur une �galit�. Les mises sont rembours�es.\n", 10);
        }
    }
}