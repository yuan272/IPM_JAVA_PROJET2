package Ecole.Jeu;

import Ecole.Personnages.Eleve;

public class Mouvement {
    private Eleve eleve;
    private String mouv;
    private String timestampp;
    private Partie partie;

    public Mouvement(Eleve eleve, String mouv, String timestampp, Partie partie) {
        this.eleve = eleve;
        this.mouv = mouv;
        this.timestampp = timestampp;
        this.partie = partie;
    }

    public Eleve getEleve() {
        return eleve;
    }

    public void setEleve(Eleve eleve) {
        this.eleve = eleve;
    }

    public String getMouv() {
        return mouv;
    }

    public void setMouv(String mouv) {
        this.mouv = mouv;
    }

    public String getTimestampp() {
        return timestampp;
    }

    public void setTimestampp(String timestampp) {
        this.timestampp = timestampp;
    }

    public Partie getPartie() {
        return partie;
    }

    public void setPartie(Partie partie) {
        this.partie = partie;
    }

    @Override
    public String toString() {
        return "Mouvement{" +
                "eleve=" + eleve.getNom() +
                ", mouv='" + mouv + '\'' +
                ", timestampp='" + timestampp + '\'' +
                ", partie=" + partie.getIdPartie() +
                '}';
    }
}
