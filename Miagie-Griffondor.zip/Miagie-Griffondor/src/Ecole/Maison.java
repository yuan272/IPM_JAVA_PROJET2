package Ecole;

public class Maison {
    private String nomMaison;  // clé primaire

    public Maison() {}

    public Maison(String nomMaison) {
        this.nomMaison = nomMaison;
    }

    public String getNomMaison() {
        return nomMaison;
    }

    public void setNomMaison(String nomMaison) {
        this.nomMaison = nomMaison;
    }

    @Override
    public String toString() {
        return "Maison{" +
                "nomMaison='" + nomMaison + '\'' +
                '}';
    }
}
