package Ecole;
import Ecole.Personnages.Eleve;
import java.sql.Date;

public class Evaluer {
    private int idEleve;
    private Matiere matiere;
    private int note;
    private Date dateEval;

    public Evaluer() {}

    public Evaluer(int idEleve, Matiere matiere, int note, Date dateEval) {
        this.idEleve = idEleve;
        this.matiere = matiere;
        this.note = note;
        this.dateEval = dateEval;
    }

    // Getters et Setters

    public int getIdEleve() {
        return idEleve;
    }

    public void setIdEleve(int idEleve) {
        this.idEleve = idEleve;
    }

    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public Date getDateEval() {
        return dateEval;
    }

    public void setDateEval(Date dateEval) {
        this.dateEval = dateEval;
    }
}
