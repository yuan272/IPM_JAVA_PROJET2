package Ecole.Personnages;

import Ecole.Matiere;

public class Professeur {
    private int idProfesseur;
    private String nom;
    private String prenom;
    private Matiere matiere;

    public Professeur(String nom, String prenom, Matiere matiere) {
        this.nom = nom;
        this.prenom = prenom;
        this.matiere = matiere;
    }
    public Professeur(){

    }



    public int getIdProfesseur() {
        return idProfesseur;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNomMatiere() {
        return matiere.getNomMatiere();
    }

    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    public void setIdProfesseur(int idProfesseur) {
        this.idProfesseur = idProfesseur;
    }

    // Méthode toString pour affichage
    @Override
    public String toString() {
        return "Professeur{" +
                "idProfesseur=" + idProfesseur +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", matiere=" + matiere.getNomMatiere() +
                '}';
    }

}
