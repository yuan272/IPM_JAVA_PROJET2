package Ecole.Personnages;

import Ecole.Maison;
import Ecole.Matiere;

import java.util.List;

import dao.EleveDAO;
import dao.MaisonDAO;
import Ecole.Personnages.Eleve;
import Ecole.Maison;

import java.util.List;

public class Dumbledore extends Professeur {

    private EleveDAO eleveDAO;
    private MaisonDAO maisonDAO;

    public Dumbledore() {
        super("Albus", "Dumbledore", null);  // Nom et prénom fixes, matière null
        this.eleveDAO = new EleveDAO();
        this.maisonDAO = new MaisonDAO();
    }
}
