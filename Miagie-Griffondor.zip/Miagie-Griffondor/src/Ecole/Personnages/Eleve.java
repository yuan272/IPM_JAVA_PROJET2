package Ecole.Personnages;

import Ecole.Maison;
import dao.EleveDAO;
import java.util.*;

import java.io.Serializable;
import java.util.ArrayList;

import Ecole.Evaluer;
import Ecole.Maison;

public class Eleve {
    private int idEleve;
    private String nom;
    private String prenom;
    private String nomMaison;
    private int totalPoints;

    // Constructeurs
    public Eleve() {
    }

    public Eleve(String nom, String prenom, String nomMaison, int totalPoints) {
        this.nom = nom;
        this.prenom = prenom;
        this.nomMaison = nomMaison;
        this.totalPoints = totalPoints;
    }

    // Getters et Setters

    public int getIdEleve() {
        return idEleve;
    }

    public void setIdEleve(int idEleve) {
        this.idEleve = idEleve;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNomMaison() {
        return nomMaison;
    }

    public void setNomMaison(String nomMaison) {
        this.nomMaison = nomMaison;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }

    @Override
    public String toString() {
        return getNom() + " " + getPrenom() + " (" + getNomMaison() + ") - " + getTotalPoints() + " points";
    }
}