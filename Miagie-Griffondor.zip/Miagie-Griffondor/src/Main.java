import Ecole.Evaluer;
import Ecole.Maison;
import Ecole.Matiere;
import Ecole.Personnages.Dumbledore;
import Ecole.Personnages.Eleve;
import Ecole.Personnages.Professeur;
import ExceptionClasses.AucunEleveTrouveException;
import ExceptionClasses.AucunProfesseurTrouveException;
import ExceptionClasses.AucuneEvaluationTrouveeException;
import ExceptionClasses.AucuneMaisonTrouveeException;
import ExceptionClasses.AucuneMatiereTrouveeException;
import ExceptionClasses.DatabaseException;
import ExceptionClasses.EleveDejaExistantException;
import ExceptionClasses.EleveNonTrouveException;
import ExceptionClasses.EvaluationDejaExistanteException;
import ExceptionClasses.EvaluationNonTrouveeException;
import ExceptionClasses.MaisonDejaExistanteException;
import ExceptionClasses.MaisonNonTrouveeException;
import ExceptionClasses.MatiereDejaExistanteException;
import ExceptionClasses.MatiereNonTrouveeException;
import ExceptionClasses.NomInvalideException;
import dao.*;

import java.sql.SQLException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws DatabaseException, MaisonDejaExistanteException, MaisonNonTrouveeException, AucuneMaisonTrouveeException, EleveDejaExistantException, SQLException, AucunEleveTrouveException, MatiereDejaExistanteException, AucuneMatiereTrouveeException, MatiereNonTrouveeException, AucunProfesseurTrouveException, EleveNonTrouveException, AucuneEvaluationTrouveeException, EvaluationNonTrouveeException, NomInvalideException, EvaluationDejaExistanteException {
        // Initialiser les DAO
        MaisonDAO maisonDAO = new MaisonDAO();
        EleveDAO eleveDAO = new EleveDAO();
        ProfesseurDAO professeurDAO = new ProfesseurDAO();
        MatiereDAO matiereDAO = new MatiereDAO();
        EvaluerDAO evaluerDAO = new EvaluerDAO();

        // Fonction pour afficher texte en défilement
        printWithDelay("== Démonstration du système scolaire magique ==\n", 1);

        // Étape 1: Ajouter des maisons
        printWithDelay("\nAjout des maisons...\n", 1);
        Maison gryffondor = new Maison("Gryffondor");
        Maison serpentard = new Maison("Serpentard");
        maisonDAO.ajouterMaison(gryffondor);
        maisonDAO.ajouterMaison(serpentard);

        // Afficher les maisons
        printWithDelay("\nMaisons ajoutées :\n", 1);
        List<Maison> maisons = maisonDAO.getMaisons();
        for (Maison maison : maisons) {
            printWithDelay(maison + "\n", 1);
        }

        // Étape 2: Ajouter des élèves
        printWithDelay("\nAjout des élèves...\n", 1);
        Eleve harry = new Eleve("Potter", "Harry", gryffondor.getNomMaison(), 1);
        Eleve draco = new Eleve("Malfoy", "Draco", serpentard.getNomMaison(), 40);

        harry.setIdEleve(eleveDAO.ajouterEleve(harry));
        System.out.println("Harry : " + harry.getIdEleve());
        draco.setIdEleve(eleveDAO.ajouterEleve(draco));
        System.out.println("Draco : " + draco.getIdEleve());

        // Afficher les élèves
        printWithDelay("\nÉlèves ajoutés :\n", 1);
        List<Eleve> eleves = eleveDAO.getEleves();
        for (Eleve eleve : eleves) {
            printWithDelay(eleve + "\n", 1);
        }

        // Ajouter des matières
        Matiere sortileges = new Matiere("Sortilèges");
        Matiere potions = new Matiere("Potions");
        Matiere metamorphose = new Matiere("Métamorphose");

        matiereDAO.ajouterMatiere(sortileges);
        matiereDAO.ajouterMatiere(potions);
        matiereDAO.ajouterMatiere(metamorphose);

        // Vérifier les matières ajoutées
        List<Matiere> matieres = matiereDAO.getMatieres();  // Si tu as une méthode pour récupérer toutes les matières
        for (Matiere matiere : matieres) {
            System.out.println(matiere);
        }

        // Étape 3: Ajouter des professeurs
        printWithDelay("\nAjout des professeurs...\n", 1);
        Matiere sortilege = matiereDAO.getMatiereByNom("Sortilèges");
        Matiere potion = matiereDAO.getMatiereByNom("Potions");
        Professeur flitwick = new Professeur("Flitwick", "Filius", sortilege);
        Professeur rogue = new Professeur("Rogue", "Severus", potion);
        professeurDAO.ajouterProfesseur(flitwick);
        professeurDAO.ajouterProfesseur(rogue);

        // Afficher les professeurs
        printWithDelay("\nProfesseurs ajoutés :\n", 1);
        List<Professeur> professeurs = professeurDAO.getProfesseurs();
        for (Professeur professeur : professeurs) {
            printWithDelay(professeur + "\n", 1);
        }

        // Étape 4: Ajouter des évaluations
        printWithDelay("\nAjout des évaluations...\n", 1);
        System.out.println("abc");
        Evaluer eval1 = new Evaluer(harry.getIdEleve(), sortileges, 90, new java.sql.Date(System.currentTimeMillis()));
        System.out.println("def");
        Evaluer eval2 = new Evaluer(draco.getIdEleve(), potions, 85, new java.sql.Date(System.currentTimeMillis()));
        evaluerDAO.ajouterEvaluation(eval1);
        System.out.println("ghi");
        evaluerDAO.ajouterEvaluation(eval2);
        System.out.println("jkl");

        // Afficher les évaluations
        printWithDelay("\nÉvaluations ajoutées :\n", 1);
        List<Evaluer> evaluationsHarry = evaluerDAO.getEvaluationsParEleve(harry.getIdEleve());
        for (Evaluer eval : evaluationsHarry) {
            printWithDelay(eval + "\n", 1);
        }

        // Étape 5: Mise à jour des notes et suppression d'une évaluation
        printWithDelay("\nMise à jour de la note de Harry...\n", 1);
        eval1.setNote(95);
        evaluerDAO.updateEvaluation(eval1);
        printWithDelay("Évaluation mise à jour : " + eval1 + "\n", 1);

        // Supprimer l'évaluation de Draco
        printWithDelay("\nSuppression de l'évaluation de Draco...\n", 1);
        evaluerDAO.deleteEvaluation(draco.getIdEleve(), "Potions");
        List<Evaluer> evaluationsDraco = evaluerDAO.getEvaluationsParEleve(draco.getIdEleve());
        printWithDelay("Nombre d'évaluations restantes pour Draco : " + evaluationsDraco.size() + "\n", 1);
    }

    // Fonction utilitaire pour afficher texte avec délai
    public static void printWithDelay(String message, int delay) {
        for (char c : message.toCharArray()) {
            System.out.print(c);
            try {
                Thread.sleep(delay);  // Pause de "delay" millisecondes entre chaque lettre
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
