package dao;

import Ecole.Matiere;
import mapper.MatiereMapper;
import ExceptionClasses.*;

import java.util.List;

public class MatiereDAO extends GenericDAO<Matiere> {
    public MatiereDAO() {
        super(new MatiereMapper());
    }

    // Méthode pour ajouter une matière
    public void ajouterMatiere(Matiere matiere) throws DatabaseException, MatiereDejaExistanteException {
        try {
            // Vérifier si la matière existe déjà
            if (getMatiereByNom(matiere.getNomMatiere()) != null) {
                throw new MatiereDejaExistanteException("Une matière avec le nom " + matiere.getNomMatiere() + " existe déjà.");
            }
            String sql = "INSERT INTO Matiere (nomMatiere) VALUES (?)";
            executeUpdate(sql, matiere.getNomMatiere());
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de l'ajout de la matière: " + matiere.getNomMatiere(), e);
        } catch (MatiereNonTrouveeException e) {
            // This exception is caught but ignored, as it means the matière doesn't exist, which is what we want
        }
    }

    // Méthode pour récupérer une matière par son nom
    public Matiere getMatiereByNom(String nomMatiere) throws DatabaseException, MatiereNonTrouveeException {
        try {
            String sql = "SELECT * FROM Matiere WHERE nomMatiere = ?";
            List<Matiere> matieres = executeQuery(sql, nomMatiere);
            if (matieres.isEmpty()) {
                throw new MatiereNonTrouveeException("Aucune matière trouvée avec le nom: " + nomMatiere);
            }
            return matieres.get(0);
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la recherche de la matière: " + nomMatiere, e);
        }
    }

    public List<Matiere> getMatieres() throws DatabaseException, AucuneMatiereTrouveeException {
        try {
            String sql = "SELECT * FROM Matiere";
            List<Matiere> matieres = executeQuery(sql);
            if (matieres.isEmpty()) {
                throw new AucuneMatiereTrouveeException("Aucune matière n'a été trouvée dans la base de données.");
            }
            return matieres;
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la récupération des matières", e);
        }
    }
}
