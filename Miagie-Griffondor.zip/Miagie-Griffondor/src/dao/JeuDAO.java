package dao;


import Ecole.Jeu.Jeu;
import mapper.JeuMapper;

import java.sql.*;
import java.util.List;
import ExceptionClasses.*;

public class JeuDAO extends GenericDAO<Jeu> {
    public JeuDAO() {
        super(new JeuMapper());
    }

        
    public void ajouterJeu(Jeu jeu) throws SQLException, DatabaseException {
        String sql = "INSERT INTO Jeu (nomJeu) VALUES (?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, jeu.getNomGame());
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("La création du jeu a échouée, aucune ligne affectée.");
            }
        }
    }

    public List<Jeu> getJeux() throws SQLException, DatabaseException {
        String sql = "SELECT * FROM Jeu";
        return executeQuery(sql);
    }


	public Jeu getJeuByNom(String string) throws JeuNonTrouveException {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Jeu WHERE nomJeu = ?";
        List<Jeu> jeux = executeQuery(sql, string);
        if (jeux.isEmpty()) {
            throw new JeuNonTrouveException("Aucun jeu trouvé avec l'ID: " + string);
        }
        return jeux.get(0);
	}
	
	public boolean jeuExiste(String nomJeu) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Jeu WHERE nomJeu = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nomJeu);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
}
