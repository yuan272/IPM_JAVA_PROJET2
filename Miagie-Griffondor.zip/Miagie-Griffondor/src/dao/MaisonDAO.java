package dao;

import Ecole.Maison;
import mapper.MaisonMapper;
import ExceptionClasses.*;

import java.util.List;

public class MaisonDAO extends GenericDAO<Maison> {
    public MaisonDAO() {
        super(new MaisonMapper());
    }

    public void ajouterMaison(Maison maison) throws DatabaseException, MaisonDejaExistanteException, MaisonNonTrouveeException {
        try {
            // Vérifier si la maison existe déjà
            if (getMaisonByNom(maison.getNomMaison()) != null) {
                throw new MaisonDejaExistanteException("Une maison avec le nom " + maison.getNomMaison() + " existe déjà.");
            }
            String sql = "INSERT INTO Maison (nomMaison) VALUES (?)";
            executeUpdate(sql, maison.getNomMaison());
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de l'ajout de la maison: " + maison.getNomMaison(), e);
        }
    }

    public List<Maison> getMaisons() throws DatabaseException, AucuneMaisonTrouveeException {
        try {
            String sql = "SELECT * FROM Maison";
            List<Maison> maisons = executeQuery(sql);
            if (maisons.isEmpty()) {
                throw new AucuneMaisonTrouveeException("Aucune maison n'a été trouvée dans la base de données.");
            }
            return maisons;
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la récupération des maisons", e);
        }
    }

    public Maison getMaisonByNom(String nomMaison) throws DatabaseException, MaisonNonTrouveeException {
        try {
            String sql = "SELECT * FROM Maison WHERE nomMaison = ?";
            List<Maison> maisons = executeQuery(sql, nomMaison);
            if (maisons.isEmpty()) {
                throw new MaisonNonTrouveeException("Aucune maison trouvée avec le nom: " + nomMaison);
            }
            return maisons.get(0);
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la recherche de la maison: " + nomMaison, e);
        }
    }

    public void deleteMaison(String nomMaison) throws DatabaseException, MaisonNonTrouveeException {
        try {
            String sql = "DELETE FROM Maison WHERE nomMaison = ?";
            int rowsAffected = executeUpdate(sql, nomMaison);
            if (rowsAffected == 0) {
                throw new MaisonNonTrouveeException("Aucune maison trouvée avec le nom: " + nomMaison);
            }
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la suppression de la maison: " + nomMaison, e);
        }
    }
}
