package dao;

import Ecole.Jeu.PropositionPartie;
import mapper.PropositionPartieMapper;
import java.sql.SQLException;
import ExceptionClasses.*;

public class PropositionPartieDAO extends GenericDAO<PropositionPartie> {
    public PropositionPartieDAO() {
        super(new PropositionPartieMapper());
    }

    public int proposerPartie(PropositionPartie proposition) throws SQLException, DatabaseException {
        String sql = "INSERT INTO PropositionPartie (mise, refuse, nomJeu, idEleve_receveur, idEleve_lanceur) VALUES (?, ?, ?, ?, ?)";
        return executeInsert(sql, proposition.getMise(), proposition.isRefuse(), proposition.getJeu().getNomGame(), 
                             proposition.getEleveReceveur().getIdEleve(), proposition.getEleveLanceur().getIdEleve());
    }

    public void accepterProposition(int idProposition) throws SQLException, DatabaseException {
        String sql = "UPDATE PropositionPartie SET refuse = false WHERE idProposition = ?";
        executeUpdate(sql, idProposition);
    }
    
    public void mettreAJourVainqueur(int idProposition, Integer idVainqueur) throws SQLException, DatabaseException {
        String sql = "UPDATE PropositionPartie SET idEleve_vainqueur = ? WHERE idProposition = ?";
        executeUpdate(sql, idVainqueur, idProposition);
    }
}