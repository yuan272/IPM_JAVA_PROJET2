package dao;

import Ecole.Personnages.Eleve;
import Ecole.Maison;
import mapper.EleveMapper;
import sql.MySQLConnection;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import ExceptionClasses.*;


public class EleveDAO extends GenericDAO<Eleve> {
    private MySQLConnection mysqlConn;

    // Constructeur
    public EleveDAO() {
        super(new EleveMapper());
        this.mysqlConn = new MySQLConnection();
    }

    public Integer ajouterEleve(Eleve eleve) throws EleveDejaExistantException, SQLException, NomInvalideException {
        // V�rifier si le nom et le pr�nom sont valides
        verifierNom(eleve.getNom());
        verifierNom(eleve.getPrenom());

        String verif = "SELECT * FROM Eleve WHERE nom = ? AND prenom = ?";
        List<Eleve> resultat = executeQuery(verif, eleve.getNom(), eleve.getPrenom());
        if (!resultat.isEmpty()) {
            throw new EleveDejaExistantException("Cet élève existe déjà");
        } else {
            String sql = "INSERT INTO Eleve (nom, prenom, nomMaison, totalPoints) VALUES (?, ?, ?, ?)";
            return executeInsert(sql, eleve.getNom(), eleve.getPrenom(), eleve.getNomMaison(), eleve.getTotalPoints());
        }
    }

    public void verifierNom(String nom) throws NomInvalideException {
        if (nom.matches(".*\\d.*")) {
            throw new NomInvalideException("Le nom ou le pr�nom ne peut pas contenir de chiffres : " + nom);
        }
    }

    // Méthode pour récupérer tous les élèves
    public List<Eleve> getEleves() throws AucunEleveTrouveException, SQLException {
        String sql = "SELECT * FROM Eleve";
        List<Eleve> resultat = executeQuery(sql);
        if(resultat.isEmpty()) {
            throw new AucunEleveTrouveException("Aucun élève n'a été trouvé");
        } else {
            return resultat;
        }
    }

    // Méthode pour récupérer un élève par ID
    public Eleve getEleveById(int idEleve) throws EleveNonTrouveException, SQLException {
        String sql = "SELECT * FROM Eleve WHERE idEleve = ?";
        List<Eleve> eleve = executeQuery(sql, idEleve);
        if (eleve.isEmpty()) {
            throw new EleveNonTrouveException("Aucun élève trouvé avec l'ID: " + idEleve);
        }
        return eleve.get(0);
 
    }

    // Méthode pour mettre à jour un élève
    public void updateEleve(Eleve eleve) throws EleveNonTrouveException, SQLException {
            String sql = "UPDATE Eleve SET nom = ?, prenom = ?, nomMaison = ?, totalPoints = ? WHERE idEleve = ?";
            int rowsAffected = executeUpdate(sql, eleve.getNom(), eleve.getPrenom(), eleve.getNomMaison(), eleve.getTotalPoints(), eleve.getIdEleve());
            if (rowsAffected == 0) {
                throw new EleveNonTrouveException("Aucun élève trouvé avec l'ID: " + eleve.getIdEleve());
            }
    }

    // Méthode pour supprimer un élève
    public void deleteEleve(int idEleve) throws EleveNonTrouveException, SQLException {
        String sql = "DELETE FROM Eleve WHERE idEleve = ?";
        int rowsAffected = executeUpdate(sql, idEleve);
        if (rowsAffected == 0) {
            throw new EleveNonTrouveException("Aucun élève trouvé avec l'ID: " + idEleve);
        }
    }
    
    public void mettreAJourPoints(int idEleve, int points) throws SQLException {
        String sql = "UPDATE Eleve SET totalPoints = totalPoints + ? WHERE idEleve = ?";
        try (Connection conn = mysqlConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, points);
            pstmt.setInt(2, idEleve);
            pstmt.executeUpdate();
        }
    }
}
