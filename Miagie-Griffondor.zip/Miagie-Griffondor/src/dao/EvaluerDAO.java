package dao;

import Ecole.Evaluer;
import Ecole.Personnages.Eleve;
import mapper.EvaluerMapper;
import java.util.List;
import java.sql.SQLException;
import ExceptionClasses.*;

public class EvaluerDAO extends GenericDAO<Evaluer> {
    private final EleveDAO eleveDAO = new EleveDAO();

    public EvaluerDAO() {
        super(new EvaluerMapper());
    }

    public void updateEvaluation(Evaluer evaluer) throws EvaluationNonTrouveeException, SQLException {
        String sql = "UPDATE evaluer SET note = ?, dateEval = ? WHERE idEleve = ? AND nomMatiere = ?";
        int rowsAffected = executeUpdate(sql, evaluer.getNote(), evaluer.getDateEval(), evaluer.getIdEleve(), evaluer.getMatiere().getNomMatiere());
        if (rowsAffected == 0) {
            throw new EvaluationNonTrouveeException("Aucune évaluation trouvée pour l'élève ID: " + evaluer.getIdEleve() + " et la matière: " + evaluer.getMatiere().getNomMatiere());
        }
    }

    public void deleteEvaluation(int idEleve, String nomMatiere) throws EvaluationNonTrouveeException, SQLException {
        String sql = "DELETE FROM evaluer WHERE idEleve = ? AND nomMatiere = ?";
        int rowsAffected = executeUpdate(sql, idEleve, nomMatiere);
        if (rowsAffected == 0) {
            throw new EvaluationNonTrouveeException("Aucune évaluation trouvée pour l'élève ID: " + idEleve + " et la matière: " + nomMatiere);
        }
    }

    public void ajouterEvaluation(Evaluer evaluer) throws EleveNonTrouveException, SQLException, EvaluationDejaExistanteException {
        // V�rifier si une �valuation existe d�j�
        String checkSql = "SELECT * FROM evaluer WHERE idEleve = ? AND nomMatiere = ?";
        List<Evaluer> existingEvals = executeQuery(checkSql, evaluer.getIdEleve(), evaluer.getMatiere().getNomMatiere());

        if (!existingEvals.isEmpty()) {
            throw new EvaluationDejaExistanteException("L'élève a déjà été évalué pour cette matière.");
        }

        // Ajout de l'�valuation
        String sql = "INSERT INTO evaluer (idEleve, nomMatiere, note, dateEval) VALUES (?, ?, ?, ?)";
        executeUpdate(sql, evaluer.getIdEleve(), evaluer.getMatiere().getNomMatiere(), evaluer.getNote(), evaluer.getDateEval());

        // Mettre � jour le total des points de l'�l�ve
        Eleve eleve = eleveDAO.getEleveById(evaluer.getIdEleve());
        if (eleve != null) {
            // Ajouter la note � son totalPoints
            int nouveauTotal = eleve.getTotalPoints() + evaluer.getNote();
            eleve.setTotalPoints(nouveauTotal);
            eleveDAO.updateEleve(eleve);  // Mise � jour dans la base de donn�es
        } else {
            throw new EleveNonTrouveException("Aucun élève trouvé avec l'ID: " + evaluer.getIdEleve());
        }
    }

    // Méthode pour récupérer les évaluations d'un élève
    public List<Evaluer> getEvaluationsParEleve(int idEleve) throws AucuneEvaluationTrouveeException, SQLException {
        String sql = "SELECT * FROM evaluer WHERE idEleve = ?";
        List<Evaluer> evaluations = executeQuery(sql, idEleve);
        if (evaluations.isEmpty()) {
            throw new AucuneEvaluationTrouveeException("Aucune évaluation trouvée pour l'élève ID: " + idEleve);
        }
        return evaluations;
    }
}
