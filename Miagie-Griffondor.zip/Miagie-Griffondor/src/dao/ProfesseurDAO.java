package dao;

import Ecole.Matiere;
import Ecole.Personnages.Professeur;
import mapper.ProfesseurMapper;
import ExceptionClasses.*;

import java.util.List;

public class ProfesseurDAO extends GenericDAO<Professeur> {

    private final MatiereDAO matiereDAO;

    public ProfesseurDAO() {
        super(new ProfesseurMapper());
        this.matiereDAO = new MatiereDAO();
    }

    public List<Professeur> getProfesseurs() throws DatabaseException, AucunProfesseurTrouveException {
        try {
            String sql = "SELECT * FROM Professeur";
            List<Professeur> professeurs = executeQuery(sql);
            if (professeurs.isEmpty()) {
                throw new AucunProfesseurTrouveException("Aucun professeur n'a été trouvé dans la base de données.");
            }
            return professeurs;
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la récupération des professeurs", e);
        }
    }

    public Professeur getProfesseurById(int idProfesseur) throws DatabaseException, ProfesseurNonTrouveException {
        try {
            String sql = "SELECT * FROM Professeur WHERE idProfesseur = ?";
            List<Professeur> professeurs = executeQuery(sql, idProfesseur);
            if (professeurs.isEmpty()) {
                throw new ProfesseurNonTrouveException("Aucun professeur trouvé avec l'ID: " + idProfesseur);
            }
            return professeurs.get(0);
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la recherche du professeur avec l'ID: " + idProfesseur, e);
        }
    }

    public Integer ajouterProfesseur(Professeur professeur) throws DatabaseException, MatiereNonTrouveeException {
        try {
            Matiere matiere = professeur.getMatiere();
            if (matiere == null) {
                throw new MatiereNonTrouveeException("La matière spécifiée est nulle.");
            }
            matiereDAO.getMatiereByNom(matiere.getNomMatiere()); // This will throw MatiereNonTrouveeException if not found
            String sql = "INSERT INTO Professeur (nom, prenom, nomMatiere) VALUES (?, ?, ?)";
            return executeInsert(sql, professeur.getNom(), professeur.getPrenom(), matiere.getNomMatiere());
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de l'ajout du professeur: " + professeur.getNom(), e);
        }
    }

    public void updateProfesseur(Professeur professeur) throws DatabaseException, MatiereNonTrouveeException, ProfesseurNonTrouveException {
        try {
            Matiere matiere = professeur.getMatiere();
            if (matiere == null) {
                throw new MatiereNonTrouveeException("La matière spécifiée est nulle.");
            }
            matiereDAO.getMatiereByNom(matiere.getNomMatiere()); // This will throw MatiereNonTrouveeException if not found

            String sql = "UPDATE Professeur SET nom = ?, prenom = ?, nomMatiere = ? WHERE idProfesseur = ?";
            int rowsAffected = executeUpdate(sql, professeur.getNom(), professeur.getPrenom(), matiere.getNomMatiere(), professeur.getIdProfesseur());
            if (rowsAffected == 0) {
                throw new ProfesseurNonTrouveException("Aucun professeur trouvé avec l'ID: " + professeur.getIdProfesseur());
            }
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la mise à jour du professeur: " + professeur.getNom(), e);
        }
    }

    public void deleteProfesseur(int idProfesseur) throws DatabaseException, ProfesseurNonTrouveException {
        try {
            String sql = "DELETE FROM Professeur WHERE idProfesseur = ?";
            int rowsAffected = executeUpdate(sql, idProfesseur);
            if (rowsAffected == 0) {
                throw new ProfesseurNonTrouveException("Aucun professeur trouvé avec l'ID: " + idProfesseur);
            }
        } catch (DatabaseException e) {
            throw new DatabaseException("Erreur lors de la suppression du professeur avec l'ID: " + idProfesseur, e);
        }
    }
}
