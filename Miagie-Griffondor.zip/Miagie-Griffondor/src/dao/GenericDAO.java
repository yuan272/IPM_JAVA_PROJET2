package dao;

import mapper.Mapper;
import sql.MySQLConnection;
import ExceptionClasses.DatabaseException;
import ExceptionClasses.MatiereNonTrouveeException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GenericDAO<T> {
    private final MySQLConnection mySQLConnection = new MySQLConnection();
    private final Mapper<T> mapper;

    public GenericDAO(Mapper<T> mapper) {
        this.mapper = mapper;
    }

    protected Connection getConnection() throws SQLException {
        return mySQLConnection.getConnection();
    }

    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            throw new DatabaseException("Error closing database resources", e);
        }
    }

    /**
     * Execute SELECT, UPDATE & DELETE operations
     * @param sql SQL string (with '?' for parameters)
     * @param params parameters arguments
     * @return affected or selected objects
     * @throws DatabaseException if a database access error occurs
     */
    public List<T> executeQuery(String sql, Object... params) throws DatabaseException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<T> results = new ArrayList<>();
        try {
            conn = getConnection();
            if (conn != null) {
                stmt = conn.prepareStatement(sql);
                if (params != null && params.length != 0) {
                    for (int i = 0; i < params.length; i++) {
                        stmt.setObject(i + 1, params[i]);
                    }
                }

                rs = stmt.executeQuery();

                while (rs.next()) {
                    T result;
					try {
						result = this.mapper.map(rs);
						results.add(result);
					} catch (DatabaseException | MatiereNonTrouveeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
                    
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error executing query: " + sql, e);
        } finally {
            closeResources(conn, stmt, rs);
        }
        return results;
    }

    /**
     * Execute INSERT operations
     * @param sql SQL string (with '?' for parameters)
     * @param params parameters arguments
     * @return created ID
     * @throws DatabaseException if a database access error occurs
     */
    public Integer executeInsert(String sql, Object... params) throws DatabaseException {
        Connection conn = null;
        PreparedStatement stmt = null;
        Integer createdId = null;
        try {
            conn = getConnection();
            if (conn != null) {
                stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
                if (params != null && params.length != 0) {
                    for (int i = 0; i < params.length; i++) {
                        stmt.setObject(i + 1, params[i]);
                    }
                }

                int affectedRows = stmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new DatabaseException("Creating record failed, no rows affected.");
                }

                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        createdId = generatedKeys.getInt(1);
                    } else {
                        throw new DatabaseException("Creating record failed, no ID obtained.");
                    }
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error executing insert: " + sql, e);
        } finally {
            closeResources(conn, stmt, null);
        }
        return createdId;
    }

    /**
     * Execute UPDATE operations
     * @param sql SQL string (with '?' for parameters)
     * @param params parameters arguments
     * @return affected row count
     * @throws DatabaseException if a database access error occurs
     */
    public int executeUpdate(String sql, Object... params) throws DatabaseException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int affectedRows = 0;

        try {
            conn = getConnection();
            if (conn != null) {
                stmt = conn.prepareStatement(sql);
                if (params != null && params.length > 0) {
                    for (int i = 0; i < params.length; i++) {
                        stmt.setObject(i + 1, params[i]);
                    }
                }
                affectedRows = stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error executing update: " + sql, e);
        } finally {
            closeResources(conn, stmt, null);
        }

        return affectedRows;
    }
}
