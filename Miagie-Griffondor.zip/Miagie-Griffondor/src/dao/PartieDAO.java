package dao;

import Ecole.Jeu.Partie;
import Ecole.Jeu.PropositionPartie;
import mapper.PartieMapper;
import java.sql.SQLException;
import java.util.List;

import ExceptionClasses.*;

public class PartieDAO extends GenericDAO<Partie> {
    public PartieDAO() {
        super(new PartieMapper());
    }

    public void enregistrerPartie(PropositionPartie proposition, Integer idVainqueur) throws SQLException, DatabaseException {
        String sql = "INSERT INTO Partie (idProposition) VALUES (?)";
        executeInsert(sql, proposition.getIdProposition());

        // Mettre � jour le vainqueur dans la table PropositionPartie
        String updateSql = "UPDATE PropositionPartie SET idEleve_vainqueur = ? WHERE idProposition = ?";
        executeUpdate(updateSql, idVainqueur, proposition.getIdProposition());
    }

    public List<Partie> getParties() throws AucunePartieTrouveeException, SQLException, DatabaseException {
        String sql = "SELECT * FROM Partie";
        List<Partie> resultat = executeQuery(sql);
        if(resultat.isEmpty()) {
            throw new AucunePartieTrouveeException("Aucune partie n'a �t� trouv�e");
        } else {
            return resultat;
        }
    }

    public Partie getPartieById(int idPartie) throws PartieNonTrouveeException, SQLException, DatabaseException {
        String sql = "SELECT * FROM Partie WHERE idPartie = ?";
        List<Partie> partie = executeQuery(sql, idPartie);
        if (partie.isEmpty()) {
            throw new PartieNonTrouveeException("Aucune partie trouvée avec l'ID: " + idPartie);
        }
        return partie.get(0);
    }

    public List<Partie> getPartiesByJoueur(int idJoueur) throws AucunePartieTrouveeException, SQLException, DatabaseException {
        String sql = "SELECT * FROM Partie WHERE idEleve_joueur1 = ? OR idEleve_joueur2 = ?";
        List<Partie> resultat = executeQuery(sql, idJoueur, idJoueur);
        if(resultat.isEmpty()) {
            throw new AucunePartieTrouveeException("Aucune partie trouvée pour le joueur avec l'ID: " + idJoueur);
        } else {
            return resultat;
        }
    }
}