package utils;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import dao.*;
import Ecole.Evaluer;
import Ecole.Maison;
import Ecole.Matiere;
import Ecole.Personnages.Eleve;
import ExceptionClasses.AucunEleveTrouveException;
import ExceptionClasses.AucuneMaisonTrouveeException;
import ExceptionClasses.AucuneMatiereTrouveeException;
import ExceptionClasses.DatabaseException;
import ExceptionClasses.EleveDejaExistantException;
import ExceptionClasses.EleveNonTrouveException;
import ExceptionClasses.EvaluationDejaExistanteException;
import ExceptionClasses.EvaluationNonTrouveeException;
import ExceptionClasses.MaisonNonTrouveeException;
import ExceptionClasses.MatiereNonTrouveeException;
import ExceptionClasses.NomInvalideException;

public class Functions {

    // Fonction pour afficher les élèves et leur maison (avec pagination)
    public static void afficherElevesEtMaison(EleveDAO eleveDAO, Scanner scanner) throws AucunEleveTrouveException, SQLException {
        printWithDelay("\nListe des élèves et leur maison :\n", 10);
        List<Eleve> eleves = eleveDAO.getEleves();
        afficherEnLot(eleveDAO, eleves, scanner);
    }

    // Fonction pour afficher les élèves par lot de 10 avec possibilité de voir plus
    public static void afficherEnLot(EleveDAO eleveDAO, List<Eleve> eleves, Scanner scanner) {
        int totalEleves = eleves.size();
        int affiches = 0;
        int lot = 10; // Nombre d'élèves affichés par lot

        for (int i = 0; i < Math.min(lot, totalEleves); i++) {
            Eleve eleve = eleves.get(i);
            printWithDelay(formatEleve(eleve) + "\n", 10); // Affichage avec délai
            affiches++;
        }

        // Si plus de 10 élèves, proposer d'afficher la suite
        while (affiches < totalEleves) {
            printWithDelay("\nAfficher les " + Math.min(lot, totalEleves - affiches) + " suivants ?\n1. Oui\n2. Non\n", 10);
            try {
                int choix = Integer.parseInt(scanner.nextLine());
                if (choix == 1) {
                    for (int i = affiches; i < Math.min(affiches + lot, totalEleves); i++) {
                        Eleve eleve = eleves.get(i);
                        printWithDelay(formatEleve(eleve) + "\n", 10);
                    }
                    affiches += lot;
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                printWithDelay("Entrée non reconnue, veuillez entrer un nombre valide.\n", 10);
            }
        }
    }

    // Fonction pour formater l'affichage d'un élève
    public static String formatEleve(Eleve eleve) {
        return "[" + eleve.getIdEleve() + "] - " + eleve.getPrenom() + " " + eleve.getNom() + " (" + eleve.getNomMaison() + ") " + eleve.getTotalPoints() + " points";
    }

    public static void creerEleveEtAffecterMaison(EleveDAO eleveDAO, MaisonDAO maisonDAO, Scanner scanner) throws SQLException, DatabaseException, AucuneMaisonTrouveeException, MaisonNonTrouveeException {
        boolean creationReussie = false;

        while (!creationReussie) {
            printWithDelay("\nCréation d'un nouvel élève\n", 10);

            String prenom = "";
            String nom = "";
            boolean nomValide = false;

            while (!nomValide) {
                try {
                    printWithDelay("Entrez le prénom de l'élève : ", 10);
                    prenom = scanner.nextLine();
                    printWithDelay("Entrez le nom de l'élève : ", 10);
                    nom = scanner.nextLine();

                    // Vérification du nom et du prénom
                    eleveDAO.verifierNom(prenom);
                    eleveDAO.verifierNom(nom);

                    nomValide = true;
                } catch (NomInvalideException e) {
                    printWithDelay("Erreur : " + e.getMessage() + "\nVeuillez réessayer.\n", 10);
                }
            }

            // Choisir la maison
            Maison maisonChoisie = null;
            while (maisonChoisie == null) {
                printWithDelay("Choisissez une maison parmi les suivantes :\n", 10);
                List<Maison> maisons = maisonDAO.getMaisons();
                for (Maison maison : maisons) {
                    printWithDelay(maison.getNomMaison() + "\n", 10);
                }
                printWithDelay("Entrez le nom de la maison : ", 10);
                String nomMaison = scanner.nextLine();

                try {
                    maisonChoisie = maisonDAO.getMaisonByNom(nomMaison);
                } catch (MaisonNonTrouveeException e) {
                    printWithDelay("Maison non trouvée, veuillez réessayer.\n", 10);
                }
            }

            Eleve nouvelEleve = new Eleve(nom, prenom, maisonChoisie.getNomMaison(), 0);

            try {
                Integer idEleve = eleveDAO.ajouterEleve(nouvelEleve);
                if (idEleve != null) {
                    printWithDelay("Élève ajouté avec succès : " + nouvelEleve + "\n", 10);
                    creationReussie = true;
                } else {
                    printWithDelay("Erreur lors de l'ajout de l'élève.\n", 10);
                }
            } catch (EleveDejaExistantException e) {
                printWithDelay("Cet élève existe déjà, veuillez recommencer.\n", 10);
            } catch (NomInvalideException e) {
                // Cette exception ne devrait pas se produire ici car nous avons déjà vérifié les noms,
                // mais c'est une bonne pratique de la gérer au cas où
                printWithDelay("Erreur inattendue : " + e.getMessage() + "\n", 10);
            }
        }
    }

    public static void evaluerEleve(EleveDAO eleveDAO, MatiereDAO matiereDAO, EvaluerDAO evaluerDAO, Scanner scanner) throws SQLException, DatabaseException, AucuneMaisonTrouveeException, MaisonNonTrouveeException, EvaluationNonTrouveeException, AucuneMatiereTrouveeException, MatiereNonTrouveeException {
        printWithDelay("\nÉvaluation d'un élève\n", 10);
        printWithDelay("Entrez l'ID de l'élève à évaluer : ", 10);
        int idEleve = lireChoixUtilisateur(scanner);
        try {
            Eleve eleve = eleveDAO.getEleveById(idEleve);
            if (eleve == null) {
                printWithDelay("Aucun élève trouvé avec cet ID.\n", 10);
                return;
            }
            printWithDelay("Liste des matières :\n", 10);
            List<Matiere> matieres = matiereDAO.getMatieres();
            for (Matiere matiere : matieres) {
                printWithDelay(matiere.getNomMatiere() + "\n", 10);
            }
            printWithDelay("Entrez le nom de la matière : ", 10);
            String nomMatiere = scanner.nextLine().toUpperCase();

            Matiere matiere = matiereDAO.getMatiereByNom(nomMatiere);
            if (matiere == null) {
                printWithDelay("Matière non trouvée.\n", 10);
                return;
            }
            int note;
            while (true) {
                printWithDelay("Entrez la note de l'élève (entre 0 et 20) : ", 10);
                try {
                    note = Integer.parseInt(scanner.nextLine());
                    if (note < 0 || note > 20) {
                        printWithDelay("La note doit être comprise entre 0 et 20.\n", 10);
                    } else {
                        break;
                    }
                } catch (NumberFormatException e) {
                    printWithDelay("Entrée non reconnue, veuillez entrer une note valide.\n", 10);
                }
            }
            Evaluer evaluation = new Evaluer(eleve.getIdEleve(), matiere, note, new java.sql.Date(System.currentTimeMillis()));
            try {
                evaluerDAO.ajouterEvaluation(evaluation);
                eleve = eleveDAO.getEleveById(idEleve); // Récupérer l'élève mis à jour
                printWithDelay("Évaluation ajoutée avec succès.\n", 10);
                printWithDelay("Nouveau total de points pour " + eleve.getPrenom() + " " + eleve.getNom() + " : " + eleve.getTotalPoints() + "\n", 10);
            } catch (EvaluationDejaExistanteException e) {
                printWithDelay("Erreur : " + e.getMessage() + "\n", 10);
                printWithDelay("Voulez-vous mettre à jour la note existante ? (O/N) : ", 10);
                String reponse = scanner.nextLine().trim().toUpperCase();
                if (reponse.equals("O")) {
                    try {
                        evaluerDAO.updateEvaluation(evaluation);
                        eleve = eleveDAO.getEleveById(idEleve); // Récupérer l'élève mis à jour
                        printWithDelay("Note mise à jour avec succès.\n", 10);
                        printWithDelay("Nouveau total de points pour " + eleve.getPrenom() + " " + eleve.getNom() + " : " + eleve.getTotalPoints() + "\n", 10);
                    } catch (SQLException ex) {
                        printWithDelay("Erreur lors de la mise à jour de la note : " + ex.getMessage() + "\n", 10);
                    }
                } else {
                    printWithDelay("L'évaluation n'a pas été modifiée.\n", 10);
                }
            } catch (EleveNonTrouveException e) {
                printWithDelay("Erreur : " + e.getMessage() + "\n", 10);
            }
        } catch (EleveNonTrouveException e) {
            printWithDelay("Erreur : " + e.getMessage() + "\n", 10);
        }
    }

    // Fonction pour afficher le classement par maison
    public static void afficherClassementMaisons(EleveDAO eleveDAO) throws AucunEleveTrouveException, SQLException {
        try{
            printWithDelay("\nClassement des maisons :\n", 10);

            List<Eleve> eleves = eleveDAO.getEleves();

            if(eleves.isEmpty()) {
                throw new AucunEleveTrouveException("Aucun élève trouvé pour générer le classement.");
            }

            HashMap<String, Integer> pointsParMaison = new HashMap<>();

            for (Eleve eleve : eleves) {
                pointsParMaison.put(eleve.getNomMaison(), pointsParMaison.getOrDefault(eleve.getNomMaison(), 0) + eleve.getTotalPoints());
            }

            pointsParMaison.entrySet()
                    .stream()
                    .sorted((e1, e2) -> e2.getValue() - e1.getValue())  // Tri par ordre décroissant
                    .forEach(entry -> printWithDelay(entry.getKey() + " : " + entry.getValue() + " points\n", 10));
        } catch (AucunEleveTrouveException e) {
            printWithDelay("Erreur : " + e.getMessage() + "\n", 10);
        } catch (SQLException e) {
            printWithDelay("Erreur de base de données : " + e.getMessage() + "\n", 10);
            throw e;  // Relance de l'exception pour que la méthode qui appelle cette fonction puisse gérer l'erreur
        }
    }

    // Fonction pour afficher le top 10 des élèves
    public static void afficherTop10Eleves(EleveDAO eleveDAO) throws SQLException {
        try {
            printWithDelay("\nTop 10 des élèves :\n", 10);
            List<Eleve> eleves = eleveDAO.getEleves();  // Récupérer la liste des élèves

            if (eleves.isEmpty()) {
                throw new AucunEleveTrouveException("Aucun élève trouvé pour afficher le top 10.");
            }

            // Trier les élèves par nombre de points décroissant et afficher les 10 premiers
            eleves.stream()
                    .sorted((e1, e2) -> e2.getTotalPoints() - e1.getTotalPoints())
                    .limit(10)
                    .forEach(eleve -> printWithDelay(eleve.getPrenom() + " " + eleve.getNom() + " : " + eleve.getTotalPoints() + " points\n", 10));

        } catch (AucunEleveTrouveException e) {
            printWithDelay("Erreur : " + e.getMessage() + "\n", 10);
        } catch (SQLException e) {
            printWithDelay("Erreur de base de données : " + e.getMessage() + "\n", 10);
            throw e;  // Relancer l'exception pour permettre une gestion au niveau supérieur
        }
    }


    // Fonction pour afficher un texte avec un délai
    public static void printWithDelay(String message, int delay) {
        try {
            for (char c : message.toCharArray()) {
                System.out.print(c);
                Thread.sleep(delay);  // Pause entre chaque caractère
            }
        } catch (InterruptedException e) {
            // Interruption détectée, arrêter proprement l'animation
            System.out.println("\nLe processus a été interrompu.");
            Thread.currentThread().interrupt();  // Réinterrompre le thread pour ne pas masquer l'exception
        }
    }

    public static Eleve selectionnerEleve(EleveDAO eleveDAO, Scanner scanner, String message) throws SQLException, AucunEleveTrouveException {
        Eleve eleveChoisi = null;
        while (eleveChoisi == null) {
            printWithDelay(message + "\n", 10);
            printWithDelay("Liste des élèves :\n", 10);
            List<Eleve> eleves = eleveDAO.getEleves();
            afficherEnLot(eleveDAO, eleves, scanner);

            printWithDelay("Entrez l'ID de l'élève choisi : ", 10);
            try {
                int idEleve = Integer.parseInt(scanner.nextLine());
                eleveChoisi = eleveDAO.getEleveById(idEleve);
                if (eleveChoisi == null) {
                    printWithDelay("Élève non trouvé, veuillez réessayer.\n", 10);
                }
            } catch (NumberFormatException e) {
                printWithDelay("Entrée non reconnue, veuillez entrer un nombre valide.\n", 10);
            } catch (EleveNonTrouveException e) {
                printWithDelay("Erreur : " + e.getMessage() + ". Veuillez réessayer.\n", 10);
            }
        }
        return eleveChoisi;
    }

    public static int demanderMise(Scanner scanner, Eleve eleve) {
        int mise = 0;
        while (mise <= 0 || mise > eleve.getTotalPoints()) {
            printWithDelay(eleve.getPrenom() + " " + eleve.getNom() + ", entrez votre mise (max " + eleve.getTotalPoints() + " points) : ", 10);
            try {
                mise = Integer.parseInt(scanner.nextLine());
                if (mise <= 0 || mise > eleve.getTotalPoints()) {
                    printWithDelay("Mise invalide. Veuillez entrer un nombre entre 1 et " + eleve.getTotalPoints() + ".\n", 10);
                }
            } catch (NumberFormatException e) {
                printWithDelay("Entrée non reconnue, veuillez entrer un nombre valide.\n", 10);
            }
        }
        return mise;
    }
    public static int lireChoixUtilisateur(Scanner scanner) {
        int choix = -1;
        boolean choixValide = false;
        while (!choixValide) {
            try {
                String input = scanner.nextLine();
                choix = Integer.parseInt(input);
                choixValide = true;
            } catch (NumberFormatException e) {
                printWithDelay("Entrée non valide. Veuillez entrer un nombre.\n", 10);
            }
        }
        return choix;
    }
}

