package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import Ecole.Jeu.Jeu;

	public class JeuMapper implements Mapper<Jeu> {
	    @Override
	    public Jeu map(ResultSet rs) throws SQLException {
	        return new Jeu(rs.getString("nomJeu"));
	    }

}