package mapper;

import Ecole.Evaluer;
import Ecole.Matiere;
import ExceptionClasses.DatabaseException;
import ExceptionClasses.MatiereNonTrouveeException;
import dao.MatiereDAO;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EvaluerMapper implements Mapper<Evaluer> {
    private MatiereDAO matiereDAO = new MatiereDAO();

    @Override
    public Evaluer map(ResultSet resultSet) throws SQLException, DatabaseException, MatiereNonTrouveeException {
        Evaluer evaluer = new Evaluer();
        evaluer.setIdEleve(resultSet.getInt("idEleve"));

        // Obtenir la matière à partir du nom dans le résultat SQL
        String nomMatiere = resultSet.getString("nomMatiere");
        Matiere matiere = matiereDAO.getMatiereByNom(nomMatiere);
        evaluer.setMatiere(matiere);

        evaluer.setNote(resultSet.getInt("note"));
        evaluer.setDateEval(resultSet.getDate("dateEval"));

        return evaluer;
    }
}

