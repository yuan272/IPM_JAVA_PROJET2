package mapper;

import Ecole.Personnages.Eleve;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EleveMapper implements Mapper<Eleve> {

    @Override
    public Eleve map(ResultSet resultSet) throws SQLException {
        // Création d'un objet Eleve
        Eleve eleve = new Eleve();

        eleve.setIdEleve(resultSet.getInt("idEleve"));
        eleve.setNom(resultSet.getString("nom"));
        eleve.setPrenom(resultSet.getString("prenom"));
        eleve.setNomMaison(resultSet.getString("nomMaison"));
        eleve.setTotalPoints(resultSet.getInt("totalPoints"));

        return eleve;
    }
}

