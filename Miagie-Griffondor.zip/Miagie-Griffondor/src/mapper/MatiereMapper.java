package mapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import Ecole.Matiere;

public class MatiereMapper implements Mapper<Matiere> {
    @Override
    public Matiere map(ResultSet resultSet) throws SQLException {
        Matiere matiere = new Matiere(resultSet.getString("nomMatiere"));
        return matiere;
    }
}
