package mapper;

import Ecole.Maison;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MaisonMapper implements Mapper<Maison> {
    @Override
    public Maison map(ResultSet resultSet) throws SQLException {
        Maison maison = new Maison();
        maison.setNomMaison(resultSet.getString("nomMaison"));
        return maison;
    }
}


