package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import ExceptionClasses.DatabaseException;
import ExceptionClasses.MatiereNonTrouveeException;

public interface Mapper<T> {
    T map(ResultSet rs) throws SQLException, DatabaseException, MatiereNonTrouveeException;
}
