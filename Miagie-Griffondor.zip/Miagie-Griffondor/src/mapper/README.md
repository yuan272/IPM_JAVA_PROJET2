# Mappers

Ces classes permettent de faire la correspondance entre un ResultSet et un objet Java.  
Elles doivent implémenter l'interface ```Mapper```.