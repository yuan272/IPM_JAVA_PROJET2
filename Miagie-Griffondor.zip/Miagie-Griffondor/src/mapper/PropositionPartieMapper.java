package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import Ecole.Jeu.PropositionPartie;
import Ecole.Jeu.Jeu;
import Ecole.Personnages.Eleve;
import dao.EleveDAO;
import dao.JeuDAO;
import ExceptionClasses.*;

public class PropositionPartieMapper implements Mapper<PropositionPartie> {
    private EleveDAO eleveDAO;
    private JeuDAO jeuDAO;

    public PropositionPartieMapper() {
        this.eleveDAO = new EleveDAO();
        this.jeuDAO = new JeuDAO();
    }

    @Override
    public PropositionPartie map(ResultSet rs) throws SQLException {
        try {
            int idProposition = rs.getInt("idProposition");
            int mise = rs.getInt("mise");
            boolean refuse = rs.getBoolean("refuse");
            
            Eleve eleveLanceur = eleveDAO.getEleveById(rs.getInt("idEleve_lanceur"));
            Eleve eleveReceveur = eleveDAO.getEleveById(rs.getInt("idEleve_receveur"));
            Eleve eleveVainqueur = rs.getInt("idEleve_vainqueur") != 0 ? eleveDAO.getEleveById(rs.getInt("idEleve_vainqueur")) : null;
            
            Jeu jeu = jeuDAO.getJeuByNom(rs.getString("nomJeu"));

            return new PropositionPartie(idProposition, mise, refuse, eleveVainqueur, eleveReceveur, eleveLanceur, jeu);
        } catch (EleveNonTrouveException | JeuNonTrouveException e) {
            throw new SQLException("Error mapping PropositionPartie: " + e.getMessage());
        }
    }
}