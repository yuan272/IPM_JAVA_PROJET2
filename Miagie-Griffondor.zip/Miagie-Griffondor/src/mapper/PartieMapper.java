package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import Ecole.Jeu.Partie;

public class PartieMapper implements Mapper<Partie> {
    @Override
    public Partie map(ResultSet rs) throws SQLException {
        return new Partie(
            rs.getInt("idPartie"),
            rs.getInt("idProposition")
        );
    }
}