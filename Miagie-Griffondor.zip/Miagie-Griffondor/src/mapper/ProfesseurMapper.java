package mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import Ecole.Matiere;
import Ecole.Personnages.Professeur;
import ExceptionClasses.DatabaseException;
import ExceptionClasses.MatiereNonTrouveeException;
import dao.MatiereDAO;


import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfesseurMapper implements Mapper<Professeur> {
    private MatiereDAO matiereDAO = new MatiereDAO();  // Utiliser le DAO pour récupérer la matière

    @Override
    public Professeur map(ResultSet resultSet) throws SQLException, DatabaseException, MatiereNonTrouveeException {
        Professeur professeur = new Professeur();
        professeur.setIdProfesseur(resultSet.getInt("idProfesseur"));
        professeur.setNom(resultSet.getString("nom"));
        professeur.setPrenom(resultSet.getString("prenom"));
        String nomMatiere = resultSet.getString("nomMatiere");
        Matiere matiere = matiereDAO.getMatiereByNom(nomMatiere);  // Appeler le DAO pour obtenir la matière
        professeur.setMatiere(matiere);

        return professeur;
    }
}

