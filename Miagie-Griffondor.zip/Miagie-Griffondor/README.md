# 🧙‍♂️✨ Poudlard ✨🧙‍♂️

Bienvenue dans le **Système Scolaire Magique de Poudlard**, un projet console qui simule la gestion des élèves, des maisons et des évaluations au sein de l'école emblématique de Poudlard. Ce projet permet d'afficher et de gérer les élèves, les maisons, les évaluations, et bien plus encore dans un univers magique, le tout depuis la console.

## ✨ Aperçu du projet

Ce projet est une simulation console qui permet de gérer les éléments suivants :
- Les **Maisons** (ex: Gryffondor, Serpentard)
- Les **Élèves**, avec leurs informations personnelles et leur maison d'appartenance
- Les **Professeurs** et leurs matières enseignées
- Les **Évaluations** des élèves pour chaque matière
- Le **Classement des Maisons** basé sur le total des points des élèves
- Le **Top 10 des Élèves** en fonction de leurs points
- Une **Partie de Chifoumi** entre deux élèves en local (le résultat est stocké en base de données)

Le projet utilise une base de données relationnelle pour stocker et gérer toutes les informations.

## 🚀 Fonctionnalités

- **Afficher les élèves et leur maison** : Affiche les élèves, leur maison et leurs points.
- **Créer un élève et l'affecter à une maison** : Ajoutez un nouvel élève et assignez-lui une maison existante.
- **Évaluer un élève** : Saisissez une note pour un élève dans une matière (note entre 0 et 20).
- **Afficher le classement des maisons** : Affiche le classement des maisons en fonction du total des points de leurs élèves.
- **Jouer à une partie de chifoumi (pierre-feuille-ciseaux)** Deux élèves peuvent s'affronter dans une partie de chifoumi pour gagner des points.


🧙‍♂️ Que la magie soit avec vous !
